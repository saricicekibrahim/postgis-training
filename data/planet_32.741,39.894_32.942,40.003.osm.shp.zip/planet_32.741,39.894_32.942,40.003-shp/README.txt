Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, http://BBBike.org
osmium2shape-1.0 by Geofabrik, http://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


This shape file was created on: Sat Dec 19 22:14:26 UTC 2015
GPS rectangle coordinates (lng,lat): 32.741,39.894 x 32.942,40.003
Script URL: http://extract.bbbike.org/?sw_lng=32.741&sw_lat=39.894&ne_lng=32.942&ne_lat=40.003&format=shp.zip&city=ankara_merkez
Name of area: ankara_merkez

We appreciate any feedback, suggestions and a donation! You can support us via
PayPal, Flattr or bank wire transfer: http://www.BBBike.org/community.html

thanks, Wolfram Schneider

--
http://www.BBBike.org - Your Cycle Route Planner
